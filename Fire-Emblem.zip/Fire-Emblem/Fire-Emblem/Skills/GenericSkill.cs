﻿namespace Fire_Emblem {
    public class GenericSkill : Skill {
        public GenericSkill(string name, string description) : base(name, description) { }
    }
}